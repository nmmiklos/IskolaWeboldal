﻿using System.Collections.Generic;
using VBJWeboldal.Models;

namespace VBJWeboldal.ViewModels
{
    public class NewsListViewModel
    {
        public List<News> News { get; set; }
    }
}
