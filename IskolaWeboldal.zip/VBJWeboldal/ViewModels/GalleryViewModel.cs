﻿using System.Collections.Generic;
using VBJWeboldal.Models;

namespace VBJWeboldal.ViewModels
{
    public class GalleryViewModel
    {
        public List<Gallery> GaleriaKep { get; set; }
    }
}
