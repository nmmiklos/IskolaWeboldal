﻿using VBJWeboldal.Models;

namespace VBJWeboldal.ViewModels
{
    public class NewsDetailsViewModel
    {
        public News HirItem { get; set; }
    }
}
