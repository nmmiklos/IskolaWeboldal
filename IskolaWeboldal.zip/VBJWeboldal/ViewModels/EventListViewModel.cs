﻿using System.Collections.Generic;
using VBJWeboldal.Models;

namespace VBJWeboldal.ViewModels
{
    public class EventListViewModel
    {
        public List<Event> Esemenyek { get; set; }
    }
}
